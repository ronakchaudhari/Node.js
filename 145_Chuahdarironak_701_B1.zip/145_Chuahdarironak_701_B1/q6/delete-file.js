const fs = require('fs');
const util = require('util');
const path = require('path');

// Promisify fs.unlink
const unlinkAsync = util.promisify(fs.unlink);

// Async function to delete a file
async function deleteFile(filePath) {
    try {
        await unlinkAsync(filePath);
        console.log(`✅ File deleted: ${filePath}`);
    } catch (error) {
        console.error(`❌ Error deleting file: ${error.message}`);
    }
}

// Example usage
const fileToDelete = path.join(__dirname, 'test.txt');  // File you want to delete

deleteFile(fileToDelete);
