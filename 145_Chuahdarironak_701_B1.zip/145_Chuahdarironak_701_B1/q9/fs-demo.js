const fs = require('fs');
const path = require('path');

// Define file and folder paths
const folder = path.join(__dirname, 'demo');
const filePath = path.join(folder, 'sample.txt');

// 1. Create a folder
fs.mkdir(folder, { recursive: true }, (err) => {
    if (err) return console.error(' Error creating folder:', err.message);
    console.log('Folder created:', folder);

    // 2. Create/write a file
    fs.writeFile(filePath, 'Hello, this is a demo file.\n', (err) => {
        if (err) return console.error('Error writing file:', err.message);
        console.log('File written:', filePath);

        // 3. Append to the file
        fs.appendFile(filePath, 'This text is appended.\n', (err) => {
            if (err) return console.error('Error appending:', err.message);
            console.log('Data appended to file.');

            // 4. Read the file
            fs.readFile(filePath, 'utf-8', (err, data) => {
                if (err) return console.error(' Error reading file:', err.message);
                console.log(' File content:\n', data);

                // 5. Get file stats
                fs.stat(filePath, (err, stats) => {
                    if (err) return console.error(' Error getting stats:', err.message);
                    console.log('File Stats:', stats);

                    // 6. Rename the file
                    const newFilePath = path.join(folder, 'renamed.txt');
                    fs.rename(filePath, newFilePath, (err) => {
                        if (err) return console.error(' Error renaming file:', err.message);
                        console.log(' File renamed to:', newFilePath);

                        // 7. Read all files in folder
                        fs.readdir(folder, (err, files) => {
                            if (err) return console.error(' Error reading folder:', err.message);
                            console.log('Files in folder:', files);

                            // 8. Delete the file
                            fs.unlink(newFilePath, (err) => {
                                if (err) return console.error(' Error deleting file:', err.message);
                                console.log(' File deleted:', newFilePath);
                            });
                        });
                    });
                });
            });
        });
    });
});
