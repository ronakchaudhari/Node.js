function toKebabCase(str) {
  return str
    .replace(/\s+/g, '-')
    .replace(/([a-z])([A-Z])/g, '$1-$2')
    .toLowerCase();
}

function toSnakeCase(str) {
  return str
    .replace(/\s+/g, '_')
    .replace(/([a-z])([A-Z])/g, '$1_$2')
    .toLowerCase();
}

function toCamelCase(str) {
  return str
    .toLowerCase()
    .replace(/([-_ ][a-z])/g, group =>
      group.toUpperCase().replace(/[-_ ]/, '')
    );
}

function toTitleCase(str) {
  return str.replace(/\w\S*/g, txt =>
    txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase()
  );
}

module.exports = {
  toKebabCase,
  toSnakeCase,
  toCamelCase,
  toTitleCase,
};
