const { toKebabCase, toSnakeCase, toCamelCase, toTitleCase } = require('string-case-tools');

console.log(toKebabCase('Hello World')); // hello-world
console.log(toSnakeCase('Hello World')); // hello_world
console.log(toCamelCase('hello world')); // helloWorld
console.log(toTitleCase('hello world')); // Hello World
