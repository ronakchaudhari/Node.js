# string-case-tools

A small utility to convert strings to:

- kebab-case
- snake_case
- camelCase
- Title Case

## Installation

```bash
npm install string-case-tools
