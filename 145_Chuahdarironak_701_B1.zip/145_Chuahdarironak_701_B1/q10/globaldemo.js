// File: global-demo.js

console.log(' Using Node.js Global Objects\n');

// __dirname
console.log('__dirname:', __dirname);

// __filename
console.log(' __filename:', __filename);

// global object (similar to window in browser)
global.myAppName = 'Node Global Demo';
console.log(' Global Variable:', global.myAppName);

// setTimeout
setTimeout(() => {
    console.log(' setTimeout: This runs after 2 seconds');
}, 2000);

// setInterval + clearInterval
let count = 0;
const interval = setInterval(() => {
    count++;
    console.log(`setInterval: ${count}`);
    if (count === 3) {
        clearInterval(interval);
        console.log('Interval cleared after 3 counts');
    }
}, 1000);

// process object
console.log(' process.platform:', process.platform);
console.log('process.version:', process.version);
console.log('process.pid:', process.pid);
