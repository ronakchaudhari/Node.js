// app.js

const readline = require('readline');
const chatbot = require('./chatbot');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: 'You: '
});

console.log("💬 Welcome to the Banking Chatbot! Type 'exit' to quit.");
rl.prompt();

rl.on('line', (line) => {
    const input = line.trim();
    const response = chatbot.getResponse(input);
    console.log('Bot:', response);

    if (input.toLowerCase() === 'exit' || input.toLowerCase() === 'bye') {
        rl.close();
    } else {
        rl.prompt();
    }
});
