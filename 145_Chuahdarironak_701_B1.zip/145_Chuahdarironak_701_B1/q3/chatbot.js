// chatbot.js

function getResponse(input) {
    input = input.toLowerCase().trim();

    if (input.includes('balance')) {
        return "Your current balance is ₹25,000.";
    } else if (input.includes('transfer')) {
        return "To transfer funds, use the mobile app or visit your nearest branch.";
    } else if (input.includes('loan')) {
        return "We offer home, car, and personal loans at competitive rates.";
    } else if (input.includes('open account')) {
        return "You can open a new account online or by visiting your nearest branch.";
    } else if (input.includes('exit') || input === 'bye') {
        return "Thank you for using the banking assistant. Goodbye!";
    } else {
        return "Sorry, I didn’t understand that. Try asking about balance, loan, or account.";
    }
}

module.exports = { getResponse };
