console.log("👋 Hello, welcome to our app!");
