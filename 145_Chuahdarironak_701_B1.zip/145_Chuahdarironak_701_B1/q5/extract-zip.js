// extract-zip.js

const fs = require('fs');
const unzipper = require('unzipper');
const path = require('path');

function extractZip(zipFilePath, outputFolderPath) {
    fs.createReadStream(zipFilePath)
        .pipe(unzipper.Extract({ path: outputFolderPath }))
        .on('close', () => {
            console.log(`✅ Extraction complete to: ${outputFolderPath}`);
        })
        .on('error', (err) => {
            console.error('❌ Error during extraction:', err.message);
        });
}

// Example usage
const zipPath = path.join(__dirname, 'myfolder.zip');            // Your zip file
const extractTo = path.join(__dirname, 'extracted-folder');      // Where to extract

extractZip(zipPath, extractTo);
