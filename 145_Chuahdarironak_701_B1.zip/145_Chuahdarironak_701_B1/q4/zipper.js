// zipper.js

const fs = require('fs');
const archiver = require('archiver');
const path = require('path');

function zipFolder(sourceFolder, outZipFile) {
    const output = fs.createWriteStream(outZipFile);
    const archive = archiver('zip', {
        zlib: { level: 9 } // Best compression
    });

    output.on('close', function () {
        console.log(`✅ ZIP file created: ${outZipFile} (${archive.pointer()} total bytes)`);
    });

    archive.on('error', function (err) {
        throw err;
    });

    archive.pipe(output);

    archive.directory(sourceFolder, false); // false = don't include full folder path inside zip
    archive.finalize();
}

// Example usage:
const sourceFolder = path.join(__dirname, 'my-folder'); // Replace with your folder
const outputZip = path.join(__dirname, 'my-folder.zip');

zipFolder(sourceFolder, outputZip);
