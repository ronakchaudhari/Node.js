const fetch = require('node-fetch');

async function fetchGoogleHomepage() {
  try {
    const response = await fetch('https://www.google.com');

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const data = await response.text(); // Get HTML as text
    console.log(data); // Print the HTML content of Google homepage
  } catch (error) {
    console.error('Error fetching Google homepage:', error.message);
  }
}

fetchGoogleHomepage();
